# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 17:30:19 2022
 
"""

import pandas as pd 
import numpy as np
import os
import sys
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import shortuuid 
# (B)
# 3. Set parameter - Year start
#                   - type of ESG metric
#                   - fulfillment period
start = datetime(2005,1,1)   
fulfill = relativedelta(years=+1)
#ret = relativedelta(years=+0.5)
ret = relativedelta(months=+12)
qtiles = 10
# the 1st tuple (0) is for how MRNA (MarketPschy) labels its metrics
# and the 2nd (1) is for the asset4.
esg_metric = {'ESG': ("ESG" ,'ESG Score'), "E": ("EnvironmentalPillar", "Environment Pillar Score"), \
              "S": ("SocialPillar", "Social Pillar Score") , "G": ("GovernancePillar", "Governance Pillar Score") }
#mypath = "C:\\Users\\jc822081\\OneDrive - James Cook University\\Academia\\Papers - Completed\\Greenwashing\\Code\\data"
os.chdir(os.path.dirname(os.path.abspath(sys.path[0])))

# Generate guid for permids (1x only)
permids_map = pd.read_csv("map_permid.csv")
#permids_map["permid2"] = [shortuuid.uuid() for x in range(len(permids_map))] 
#guid_map = permids_map[["permid", "permid2"]]
#guid_map.to_csv("guid_permid_map.csv")
#permids_map.to_csv("map_permid.csv")

# Group into industries
industry_map = permids_map[["permid", "industry"]]
industries_ = industry_map.groupby("industry").count()
industries = ["Consumer Cyclicals", "Consumer Non-Cyclicals", "Basic Materials", "Energy", "Utilities", "Technology", "Financials", "Healthcare"] 
industry_map2 = {"consumer" : ["Consumer Cyclicals", "Consumer Non-Cyclicals"], "brown": ["Basic Materials", "Energy", "Utilities"], "green" : ["Technology", "Financials", "Healthcare"] }
industry_map2 = { v: k for k, l in industry_map2.items() for v in l}

# ESG performance scores
df_asset4_1 = pd.read_csv("df_asset4.csv") 
df_asset4_1["Date"] = df_asset4_1["Date"].map(lambda x : datetime.strptime(x, "%Y-%m-%d") + timedelta(days=1))
df_asset4 = df_asset4_1[df_asset4_1["country"]=="United States"]
df_asset4 = df_asset4[["permid2", 'ESG Score', "Environment Pillar Score", "Social Pillar Score", "Governance Pillar Score", "Date"]] 

### Comment out this section if you want ony inudstry level results
df_asset4 = df_asset4.join(permids_map.set_index("permid2"), on = "permid2")
df_asset4 = df_asset4[df_asset4["industry"].isin(industries)]
df_asset4["industry_type"] = df_asset4["industry"].map(lambda x : industry_map2[x])

##  Actual esg data input
df_esg = pd.read_csv("df_esg.csv")
df_esg["Date"] = df_esg["Yr Mth"].map(lambda x : datetime.strptime(x + "-01", "%Y-%m-%d") + relativedelta(months=+1))
df_esg = df_esg[["permid2", "ESG", "EnvironmentalPillar", "SocialPillar", "GovernancePillar",  "Date"]]
df_esg = df_esg[df_esg["permid2"].isin(df_asset4["permid2"].unique())]

# price data
df_price = pd.read_csv("df_price.csv") # these are monthly prices  
df_price["Date"] = df_price["Yr Month"].map(lambda x : datetime( int(x[0:4]), int(x[5:7]), 1))
df_price = df_price[["permid2", "Close", "Date"]]

 
# 4. Sort the ESG sentiment at the start 
dat = np.arange(0,17) # for full = 2

stop = 0
df_greenwash = pd.DataFrame()
list_dates = [start + relativedelta(years=+d) for d in dat] #, datetime(2021,1,1)]

for ind in ["overall", "green", "brown", "consumer"]:
    #print(ind)
    if ind != "overall":
        df_asset4_0 = df_asset4[df_asset4["industry_type"]==ind]  # green, brown, consumer
    else:
        df_asset4_0 = df_asset4 
    df_esg_0 = df_esg[df_esg["permid2"].isin(df_asset4_0["permid2"].unique())]
    for key, value in esg_metric.items():
        #print(key)
        df_asset4_1 = df_asset4_0[["permid2", value[1], "Date"]]
        df_asset4_1 = df_asset4_1.dropna(subset = value[1], how='all')
        df_esg_1    = df_esg_0[["permid2", value[0], "Date"]]
        df_esg_1 = df_esg_1.dropna(subset = value[0], how='all')
        
        n_list = []
        esg_scores_list = []
        greenwash_prem = []
        n_common_list = []
        
        for i in list_dates:
            try:
                #print(i)
                # this is to ensure that the metrics for both asset4 and 
                df_esg_2 = df_esg_1[df_esg_1["Date"]==i]
                df_asset4_2 = df_asset4_1[df_asset4_1["Date"] == i + fulfill]
                                
                df_esg_2 = df_esg_2[df_esg_2["permid2"].isin(df_asset4_2["permid2"].unique())]
                df_asset4_2 = df_asset4_2[df_asset4_2["permid2"].isin(df_esg_2["permid2"].unique())]
                
                n1 = len(df_esg_2)
                n2 = len(df_asset4_2)
                assert n1 == n2
                n_list.append(n1)
                
                # sort the permids
                df_esg_2 = df_esg_2.sort_values(by =  value[0])
                df_esg_2["qtiles"] = pd.qcut(df_esg_2[value[0]], qtiles, duplicates = "drop", labels = False)
                df_esg_top = df_esg_2[df_esg_2["qtiles"]==qtiles-1]
                df_esg_scores = np.mean(df_esg_top[value[0]])
                esg_scores_list.append(df_esg_scores) 
                
                df_asset4_2 = df_asset4_2.sort_values(by =  value[1])
                df_asset4_2["qtiles"] = pd.qcut(df_asset4_2[value[1]], qtiles, duplicates = "drop", labels = False)
                max_q = np.max(df_asset4_2["qtiles"])
                # this is needed as many of the ASSET4 scores are 0, causing a 'jam' at the bottom of the quantiles
                # as a result, the top quantil may not be 9, but sometimes 5. However, note that the no of stocks in the quantile 
                # are still the same. 
                df_asset4_top = df_asset4_2[df_asset4_2["qtiles"]==max_q]  
                # 5. Obtain the greenwashing premium 
                # obtain the stock returns in the portfolios
                dates_req = [i, i+ret]
                df_price_req = df_price[df_price["Date"].isin(dates_req)]
                                
            # obtain common permids 
                df_common = set(df_esg_top["permid2"]) - set(df_asset4_top["permid2"]) # firms that greenwash
                         
                # these already contain the prices for the begin and end of period dates
                df_price_top_esg = df_price_req[df_price_req["permid2"].isin(df_common)] 
                df_price_top_esg_pivot = df_price_top_esg.pivot(index= ["permid2"], columns = ["Date"], values = ["Close"])
                df_price_top_esg_ret = np.log(df_price_top_esg_pivot["Close"][i + ret]/df_price_top_esg_pivot["Close"][i])  
                df_greenwash_ret = np.sum(df_price_top_esg_ret)/n1  #- 0.25* np.mean(df_price_bot_esg_ret)
                                  
                greenwash_prem.append(df_greenwash_ret)

                if len(df_common)/n1*qtiles > 1:
                    n_common_list.append(1.0)
                else:
                    n_common_list.append(len(df_common)/n1*qtiles)   
            except IndexError:
                continue     
        greenwash = {"dates" : list_dates, "premium": greenwash_prem, "metric": [key] * len(list_dates) , "TRMA_scores": esg_scores_list, "no_of_firms": n_list, "No_firms_greenwash%": n_common_list, "industry": [ind] * len(list_dates)}
        #greenwash = {"dates" : list_dates, "News_premium": df_news_prem, "Compliance_prem" : df_asset4_prem, "Common_%": n_common_list }
        if stop == 0:
            df_greenwash = pd.DataFrame.from_dict(greenwash)
            stop =1
        else:
            df_greenwash = pd.concat([df_greenwash, pd.DataFrame.from_dict(greenwash)])
            
df_greenwash.to_clipboard()

