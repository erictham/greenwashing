# -*- coding: utf-8 -*-
"""
Created on Fri Nov 11 23:20:38 2022

@author: jc822081
"""
# Greenwashing premium
# (A) 
# 1. Read in data for ESG sentiment and obtain monthly averages
# -*- coding: utf-8 -*-

import pandas as pd 
import zipfile
import os 
from datetime import date
from functools import reduce
import numpy as np
import statsmodels.api as sm
from dateutil.relativedelta import relativedelta

mypath = "C:\\Users\\jc822081\\OneDrive - James Cook University\\Academia\\Greenwashing\\Code\\data"

###############################################
# 1. Read in data for ASSET4 data 
# os.chdir(mypath + "\\asset4") 
# # Combine (1) and (2) together. Obtain their prices to calculate returns later.
# # Segment the firms into industries and also calculate the country as a wholey 
# cols = ["Instrument", "Period End Date", "ESG Score", "Environment Pillar Score", "Social Pillar Score", "Governance Pillar Score"]
# df_asset4 = pd.DataFrame()

# filenames = next(os.walk(mypath + "\\asset4"), (None, None, []))[2] 
# stop= 1
# for f in filenames: 
#     df = pd.read_csv(f,sep=",")
#     df = df[cols]
#     if stop == 1:
#         df_asset4 = df
#         stop = stop + 1
#     else:
#         df_asset4 = pd.concat([df_asset4,df], axis=0)
# df_asset4 = df_asset4.rename(columns={"Instrument": "permid", "Period End Date":"Date"}) 
# permids = df_asset4["permid"].unique()

# # map to permids 
# mypath = "C:\\Users\\jc822081\\OneDrive - James Cook University\\Academia\\Greenwashing\\Code\\data"
# os.chdir(mypath) 
# permids_map = pd.read_csv("map_permid.csv")
# #permids_map = permids_map[permids_map["country"]=="United States"]
# permids_map = permids_map[["permid", "orgname", "country", "industry"]]
# df_asset = df_asset4.join(permids_map.set_index("permid"), on="permid")
# df_asset = df_asset[df_asset["country"]=="United States"]
# df_asset.to_csv(mypath + "\\df_asset4.csv")

##########################################
# 2. Read in ESG sentiment data 
# os.chdir(mypath + "\\monthly") 
# prefix = "PRO.Archive.CMPNY_ESG.W365_UDAI."
# years = range(2003,2022)
# months = ["01", "06", "07", "12"]

# cols = ["windowTimestamp","assetCode", "ESG", "EnvironmentalPillar", "GovernancePillar", "SocialPillar"]
# col_scores = [ "ESG", "EnvironmentalPillar", "GovernancePillar", "SocialPillar"] 
# df2  = pd.DataFrame() #names=["assetCode","date"], columns=["buzz","Emissions","EnvironmentalInnovation"])

# print ("Finished asset4")
# stop= 1
# i=1
# for yr in years:
#      for mth in months:
#          try:
#             zf = zipfile.ZipFile(prefix + str(yr) + str(mth) + ".0400.zip") 
#         #f = f.replace("zip", "txt")
#             df = pd.read_csv(zf.open(prefix + str(yr) + str(mth) + ".0400.txt"),sep="\t")
#          except FileNotFoundError:
#             break
#          except KeyError:  # there are some errors with file names from 202102 onwards
#             df = pd.read_csv(zf.open(prefix + str(yr) + str(mth) + ".040" + str(i) + ".txt"),sep="\t")
#             i=i+1                 
#          df = df[cols]
#          df["Yr Mth"] = str(yr) + "-" + str(mth)

#          if stop == 1:
#             df2 = df
#             stop = stop + 1
#          else:
#             df2 = pd.concat([df2,df], axis=0)

# df2 = df2[df2["assetCode"].isin(permids)]
# df2 = df2.rename(columns={"assetCode":"permid"})
# df3 = df2.groupby(["permid", "Yr Mth"], as_index=False).mean() 
# df3 = df3.dropna(subset = col_scores, how='all')  # drop only if all the column values are NA
# df3.to_csv(mypath + "\\df_esg.csv")
# print ("Finished esg")
# -----------------------------------------------------------------------
# 3. Read in prices for permids
df_ref = pd.read_csv(mypath + "\\reference-data.csv")
df_ref = df_ref[df_ref["country"]=="USA"]
df_ref_1 = df_ref[["permid", "RIC" ]]

# all the relevant dates for the 
df_price = pd.read_csv(mypath + "\\raw_crsp_US_prices.csv")
df_price = df_price.join(df_ref_1.set_index("RIC"), on="tic")
df_price["Yr Month"] = df_price["datadate"].map(lambda x : date(int(str(x)[0:4]), int(str(x)[4:6]), 1))

df_price1 = df_price[["permid", "Yr Month", "prccd", "cshoc"]]  
df_price1 = df_price1.groupby(["permid", "Yr Month"], as_index=False).mean() 
df_price1 = df_price1.rename(columns = {"prccd": "Close", "cshoc": "NoOfShares"})
df_price1.to_csv(mypath + "\\df_price.csv")

# Calculate mkt cap 
df_price2 =df_price1[["permid", "Yr Month", "Close", "NoOfShares" ]]
df_price2["mkt_cap"] = np.log(df_price1["Close"] * df_price1["NoOfShares"])  # mkt cap
df_price2 = df_price2[df_price2["mkt_cap"].apply(lambda x : not np.isinf(x))] # remove inf values

# Obtain monthly returns and momentum
df_price3 = df_price2[["permid", "Yr Month", "Close"]]
df_price4 = df_price3.pivot_table(index = ["Yr Month"], columns = ["permid"])
df_price5 = df_price4.pct_change()  # monthly returns
df_price5["Yr Month"] = df_price5.index
df_price6 = pd.melt(df_price5, id_vars = "Yr Month" )
del df_price6[None] 
df_price6 = df_price6.dropna()  # bear in mind to delete the zeroes -> are they genuinue?
df_price6 = df_price6.rename(columns = {"value":"Mth Ret"})

df_price5 = df_price5.drop("Yr Month", axis=1)
df_price_lag1 = df_price5.shift(1)
df_price_lag2 = df_price5.shift(2)
df_price_lag3 = df_price5.shift(3)
df_price_lag4 = df_price5.shift(4)
df_price_lag5 = df_price5.shift(5)
df_price_lag6 = df_price5.shift(6)
df_price_lag7 = df_price5.shift(7)
df_price_lag8 = df_price5.shift(8)
df_price_lag9 = df_price5.shift(9)
df_price_lag10= df_price5.shift(10)
df_price_lag11= df_price5.shift(11)
df_price_lag12= df_price5.shift(12)
#df_price7 = 0.083333 * reduce(lambda a, b: a.add(b), [df_price_lag1, df_price_lag2, df_price_lag3, df_price_lag4, df_price_lag5, df_price_lag6, df_price_lag7, df_price_lag8, df_price_lag9, df_price_lag10, df_price_lag11, df_price_lag12])
df_price7 = 0.166666 * reduce(lambda a, b: a.add(b), [df_price_lag1, df_price_lag2, df_price_lag3, df_price_lag4, df_price_lag5, df_price_lag6])

df_price8 = pd.melt(df_price7, ignore_index = False)
del df_price8[None]
df_price8 = df_price8.rename(columns = {"value":"MomentumL1Y"})
df_price8 = df_price8.dropna()
df_price8["Yr Month"] = df_price8.index
df_price8.index.names = ['No']
df_price9 = pd.merge(df_price8, df_price6, left_on = ["permid", "Yr Month"], right_on = ["permid", "Yr Month"]) 

# 4. Obtain the firm fundamental data from WRDS
df_fundamentals = pd.read_csv(mypath + "\\raw_crsp_US_fun_ratios.csv")
df_ref_1 = df_ref[["permid", "RIC" ]]
df_fundamentals = df_fundamentals.join(df_ref_1.set_index("RIC"), on="TICKER")
df_fundamentals = df_fundamentals[["permid", "public_date", 'bm', 'sale_invcap', 'sale_equity', 'sale_nwc']]
df_fundamentals["Yr Month"] = df_fundamentals["public_date"].map(lambda x : date(int(str(x)[0:4]), int(str(x)[4:6]), 1))

# obtain increase in sales figures
# unfortunately needt to do this one variable by one variable
df_fundamentals1_1 = df_fundamentals[["permid", "Yr Month", 'sale_invcap']] # , 'sale_equity', 'sale_nwc']]
df_fundamentals1_2 = df_fundamentals1_1.groupby(["permid", "Yr Month"], as_index=False).mean() 
df_fundamentals1_2 = df_fundamentals1_2[df_fundamentals1_2["Yr Month"].map(lambda x : x.month ==1)]
df_fundamentals1_2_pivot = df_fundamentals1_2.pivot_table(index = ["Yr Month"], columns = "permid", values = 'sale_invcap')
df_fundamentals1_2_ret = df_fundamentals1_2_pivot.pct_change()
df_fundamentals1_2_ret["Yr Month"] = df_fundamentals1_2_ret.index
df_fundamentals1_2_ret = df_fundamentals1_2_ret.shift(-1)
df_fundamentals1_3 = pd.melt(df_fundamentals1_2_ret, id_vars = "Yr Month", var_name = "permid" )
df_fundamentals1_3 = df_fundamentals1_3.dropna()
df_fundamentals1_3a = df_fundamentals1_3.rename(columns = {"value": "sale_invcap"})

df_fundamentals1_1 = df_fundamentals[["permid", "Yr Month", 'sale_equity']] # , 'sale_equity', 'sale_nwc']]
df_fundamentals1_2 = df_fundamentals1_1.groupby(["permid", "Yr Month"], as_index=False).mean() 
df_fundamentals1_2 = df_fundamentals1_2[df_fundamentals1_2["Yr Month"].map(lambda x : x.month ==1)]
df_fundamentals1_2_pivot = df_fundamentals1_2.pivot_table(index = ["Yr Month"], columns = "permid", values = 'sale_equity')
df_fundamentals1_2_ret = df_fundamentals1_2_pivot.pct_change()
df_fundamentals1_2_ret["Yr Month"] = df_fundamentals1_2_ret.index
df_fundamentals1_2_ret = df_fundamentals1_2_ret.shift(-1)
df_fundamentals1_3 = pd.melt(df_fundamentals1_2_ret, id_vars = "Yr Month", var_name = "permid" )
df_fundamentals1_3 = df_fundamentals1_3.dropna()
df_fundamentals1_3b = df_fundamentals1_3.rename(columns = {"value": "sale_equity"})

df_fundamentals1_1 = df_fundamentals[["permid", "Yr Month", 'sale_nwc']] # , 'sale_equity', 'sale_nwc']]
df_fundamentals1_2 = df_fundamentals1_1.groupby(["permid", "Yr Month"], as_index=False).mean() 
df_fundamentals1_2 = df_fundamentals1_2[df_fundamentals1_2["Yr Month"].map(lambda x : x.month ==1)]
df_fundamentals1_2_pivot = df_fundamentals1_2.pivot_table(index = ["Yr Month"], columns = "permid", values = 'sale_nwc')
df_fundamentals1_2_ret = df_fundamentals1_2_pivot.pct_change()
df_fundamentals1_2_ret["Yr Month"] = df_fundamentals1_2_ret.index
df_fundamentals1_2_ret = df_fundamentals1_2_ret.shift(-1)
df_fundamentals1_3 = pd.melt(df_fundamentals1_2_ret, id_vars = "Yr Month", var_name = "permid" )
df_fundamentals1_3 = df_fundamentals1_3.dropna()
df_fundamentals1_3c = df_fundamentals1_3.rename(columns = {"value": "sale_nwc"})
df_fundamentals1_3all = pd.merge(pd.merge(df_fundamentals1_3a, df_fundamentals1_3b, on=["permid","Yr Month"]), df_fundamentals1_3c, on=["permid","Yr Month"]) 


### Obtaining other fundamental values

df_fundamentals1 = pd.merge(df_fundamentals, df_price9, left_on = ["permid", "Yr Month"], right_on = ["permid", "Yr Month"])
del df_fundamentals1["public_date"]

df_price1_1 = df_price2[["permid", "Yr Month", "mkt_cap"]]
df_price1_1 = df_price1_1.dropna()

# some errors with df_fundamentals2
df_fundamentals2 = df_fundamentals1[df_fundamentals1["Yr Month"].map(lambda x : x.month ==1 or x.month ==12)]
# still error
#df_fundamentals3 = df_fundamentals2.merge(df_price1_1 , left_on = ["permid", "Yr Month"], right_on = ["permid", "Yr Month"])
# weird bug here. When run step by step, it works ok, 
# but when run as a program, it fails. 
df_fundamentals4 = df_fundamentals2.merge(df_price1_1 , validate = "one_to_one", left_on = ["permid", "Yr Month"], right_on = ["permid", "Yr Month"])
df_fundamentals4 = df_fundamentals4[['permid', 'bm', 'Yr Month', 'MomentumL1Y', 'Mth Ret', "mkt_cap"]]
df_fundamentals4.to_csv(mypath + "\\df_fundamentals.csv")

# 5. do OLS on each permid to obtain coefficients for control variables
start = date(2005,1,1)
dat = np.arange(0,17) # for full = 2
keydf_greenwash = pd.DataFrame()
x_dates1 = [start + relativedelta(years=+d) for d in dat]
fulfill = relativedelta(months=+11)
x_dates2 = [d + fulfill for d in x_dates1]
x_dates2.extend(x_dates1)

df_price1_1 = df_price1[df_price1["Yr Month"].isin(x_dates2)]
df_price1_1_pivot = df_price1_1.pivot(index= ["permid"], columns = ["Yr Month"], values = ["Close"])

df_price1_1_ret = {}
for i in x_dates1:
    df_price1_1_ret[i] = np.log(df_price1_1_pivot["Close"][i + fulfill]/df_price1_1_pivot["Close"][i])  

df_price1_1_ret = pd.DataFrame.from_dict(df_price1_1_ret)
df_price1_1_ret["permid"] = df_price1_1_ret.index
df_price1_1_ret = df_price1_1_ret.melt(id_vars="permid",var_name = "Date", value_name = "Yr Ret")
df_price1_1_ret = df_price1_1_ret.dropna()

beta_bm = []
beta_mktcap = []
beta_mom = [] 
beta_const = []
permid_list = []
rsquare = []
nobs = []

# something wrong with this statement
# df_price1_1_ret for same permid and date -> why so many mthly returns?
df_fundamentals5 = df_fundamentals4.merge( df_price1_1_ret, left_on=["permid","Yr Month"], right_on = ["permid", "Date"])
# # why so many mkt cap?
df_fundamentals5 = df_fundamentals5[["permid", "bm" , "mkt_cap", "MomentumL1Y", "Yr Month", "Yr Ret"]]
df_fundamentals5 = df_fundamentals5.dropna()
permids = df_fundamentals5["permid"].unique() 

for pid in permids:
    try:
        df_reg = df_fundamentals5[df_fundamentals5["permid"]==pid]
        X = df_reg[["bm", "mkt_cap",  "MomentumL1Y"]]
        #X = sm.add_constant(X, prepend = False)
        Y =  df_reg[["Yr Ret"]]
        # why is Y all the same
        
        res = sm.OLS(Y, X).fit()
        if res.nobs > 4:   # there must be enough observations
            beta_bm.append(res.params["bm"])
            beta_mktcap.append(res.params["mkt_cap"])
            beta_mom.append(res.params["MomentumL1Y"])
            #beta_const.append(res.params["const"])
            rsquare.append(res.rsquared)
            nobs.append(res.nobs)
            permid_list.append(pid)
        else:
            print(pid)
    except ValueError:
        print(pid)
betas = {"permid" : permid_list, "beta_bm":beta_bm, "beta_mktcap":beta_mktcap, "beta_mom":beta_mom, "beta_const" : beta_const, "rsquare": rsquare, "No obs": nobs}
betas = {"permid" : permid_list, "beta_bm":beta_bm, "beta_mktcap":beta_mktcap, "beta_mom":beta_mom,  "rsquare": rsquare, "No obs": nobs}

df_betas = pd.DataFrame.from_dict(betas)
df_betas.to_csv(mypath + "\\df_betas.csv")
print(len(df_betas))

df_fundamentals1_3all.to_csv(mypath + "df_sales.csv")
