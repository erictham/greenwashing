# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 17:30:19 2022

@author: jc822081
"""

import pandas as pd 
import numpy as np
import os 
from datetime import datetime, timedelta, date
from matplotlib import pyplot as plt
from dateutil.relativedelta import relativedelta
from scipy.stats import ttest_1samp
import statsmodels.api as sm
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
pd.options.mode.chained_assignment = None  # default='warn'

# (B)
# 3. Set parameter - Year start
#                   - type of ESG metric
#                   - fulfillment period
start = date(2005,1,1)   
fulfill = relativedelta(months=+11)
#ret = relativedelta(years=+0.5)
ret = relativedelta(months=+11)
qtiles = 10
# the 1st tuple (0) is for how MRNA (MarketPschy) labels its metrics
# and the 2nd (1) is for the asset4.
esg_metric = {'ESG': ("ESG" ,'ESG Score'), "E": ("EnvironmentalPillar", "Environment Pillar Score"), \
              "S": ("SocialPillar", "Social Pillar Score") , "G": ("GovernancePillar", "Governance Pillar Score") }
mypath = "C:\\Users\\jc822081\\OneDrive - James Cook University\\Academia\\Greenwashing\\Code\\data"
os.chdir(mypath)

# Dissect into industries
permids_map = pd.read_csv("map_permid.csv")
permids_map = permids_map[permids_map["country"]=="United States"]
permids_map = permids_map[["permid", "industry"]]
industries_ = permids_map.groupby("industry").count()
industries = ["Consumer Cyclicals", "Consumer Non-Cyclicals", "Basic Materials", "Energy", "Utilities", "Technology", "Financials", "Healthcare"] 

industry_map = {"consumer" : ["Consumer Cyclicals", "Consumer Non-Cyclicals"], "brown": ["Basic Materials", "Energy", "Utilities"], "green" : ["Technology", "Financials", "Healthcare"] }
industry_map = { v: k for k, l in industry_map.items() for v in l}

df_asset4_1 = pd.read_csv("df_asset4.csv")
df_asset4_1["Date"] = df_asset4_1["Date"].map(lambda x : date(int(str(x)[:4]), int(str(x)[5:7]) ,1) )
df_asset4 = df_asset4_1[df_asset4_1["country"]=="United States"]
df_asset4 = df_asset4[["permid", 'ESG Score', "Environment Pillar Score", "Social Pillar Score", "Governance Pillar Score", "Date"]] 

### Comment out this section if you want ony inudstry level results
df_asset4 = df_asset4.join(permids_map.set_index("permid"), on = "permid")
df_asset4 = df_asset4[df_asset4["industry"].isin(industries)]
df_asset4["industry_type"] = df_asset4["industry"].map(lambda x : industry_map[x])

##  Actual data input -> ESG RNA scores
df_esg = pd.read_csv("df_esg.csv") 
df_esg["Date"] = df_esg["Yr Mth"].map(lambda x : date(int(str(x)[:4]), int(str(x)[5:7]), 1)) #+ relativedelta(months=+1))
df_esg1 = df_esg[["permid", "ESG", "EnvironmentalPillar", "SocialPillar", "GovernancePillar",  "Date"]]
df_esg2 = df_esg1[df_esg1["permid"].isin(df_asset4["permid"].unique())]

# price data
df_price = pd.read_csv("df_price.csv") # these are monthly prices
# it matters whether dateime or date -> different types.
df_price["Date"] = df_price["Yr Month"].map(lambda x : date( int(str(x)[0:4]), int(str(x)[5:7]), 1))
df_price = df_price[["permid", "Close", "Date"]]

# sales fundamental data
df_fundamentals = pd.read_csv("df_fundamentals.csv") # contain firm fundamental data
df_fundamentals["Date"] = df_fundamentals["Yr Month"].map(lambda x : date(int(x[:4]), int(x[5:7]),1) )
df_fundamentals_2 = df_fundamentals[["permid", "Date"]] #, sales_type]]
df_fundamentals_6 = df_fundamentals[["permid", "Date", "bm", 'MomentumL1Y', 'mkt_cap']]

# sales figures
df_sales = pd.read_csv("df_sales.csv") 
sales_type = "sale_equity"      # 'sale_invcap', 'sale_equity', 'sale_nwc'
df_sales["Yr Month"] = df_sales["Yr Month"].map(lambda x : date(int(x[0:4]), int(x[6:7]), 1))
df_greenwash_prem = pd.DataFrame()
iniit = 0

# read in equity beta results for control variables
df_betas = pd.read_csv("df_betas.csv")

# 4. Sort the ESG sentiment at the start
#dat = np.arange(0,17)
dat = np.arange(0,16) # for full = 2

stop = 0
df_greenwash = pd.DataFrame()
list_dates = [start + relativedelta(years=+d) for d in dat] #, datetime(2021,1,1)]
xdates = [date(2005,1,1),date(2010,1,1),date(2015,1,1), date(2021,1,1)]

os.chdir("C://Users//jc822081//OneDrive - James Cook University//Academia//Greenwashing")

for ind in ["overall", "green", "brown", "consumer"]:
    if ind != "overall":
        df_asset4_0 = df_asset4[df_asset4["industry_type"]==ind]  # green, brown, consumer
    else:
        df_asset4_0 = df_asset4 
    df_esg_2 = df_esg2[df_esg2["permid"].isin(df_asset4_0["permid"].unique())]
    
    for key, value in esg_metric.items():
        df_asset4_1 = df_asset4_0[["permid", value[1], "Date"]]
        df_asset4_1 = df_asset4_1.dropna(subset = value[1], how='all')
        df_esg_3    = df_esg_2[["permid", value[0], "Date"]]
        df_esg_4 = df_esg_3.dropna(subset = value[0], how='all')
        
        n_list = []
        esg_scores_list = []
        greenwash_prem = []
        n_common_list = []     
        correl_list = []
        for i in list_dates:
            try:
                #print(i)
                # this is to ensure that the metrics for both asset4 and 
                df_esg_5 = df_esg_4[df_esg_4["Date"]==i]
                df_asset4_2 = df_asset4_1[df_asset4_1["Date"] == i + fulfill]
                                
                df_esg_6 = df_esg_5[df_esg_5["permid"].isin(df_asset4_2["permid"].unique())]
                df_asset4_2 = df_asset4_2[df_asset4_2["permid"].isin(df_esg_6["permid"].unique())]
                
                n1 = len(df_esg_6)
                n2 = len(df_asset4_2)
                assert n1 == n2
                n_list.append(n1)
                
                # sort the permids
                df_esg_6 = df_esg_6.sort_values(by =  value[0])
                df_esg_6["qtiles"] = pd.qcut(df_esg_6[value[0]], qtiles, duplicates = "drop", labels = False)
                df_esg_top = df_esg_6[df_esg_6["qtiles"]==qtiles-1]
                df_esg_scores = np.mean(df_esg_top[value[0]])
                esg_scores_list.append(df_esg_scores) 
                
                df_asset4_2 = df_asset4_2.sort_values(by =  value[1])
                df_asset4_2["qtiles"] = pd.qcut(df_asset4_2[value[1]], qtiles, duplicates = "drop", labels = False)
                max_q = np.max(df_asset4_2["qtiles"])
                # this is needed as many of the ASSET4 scores are 0, causing a 'jam' at the bottom of the quantiles
                # as a result, the top quantil may not be 9, but sometimes 5. However, note that the no of stocks in the quantile 
                # are still the same. 
                df_asset4_top = df_asset4_2[df_asset4_2["qtiles"]==max_q]  
                # 5. Obtain the greenwashing premium 
                # obtain the stock returns in the portfolios
                dates_req = [i, i+ret]
                df_price_req = df_price[df_price["Date"].isin(dates_req)]
                
                # obtain common permids 
                df_common = set(df_esg_top["permid"]) - set(df_asset4_top["permid"]) # firms that greenwash
                         
                # these already contain the prices for the begin and end of period dates
                df_price_top_esg = df_price_req[df_price_req["permid"].isin(df_common)] 
                df_price_top_esg_pivot = df_price_top_esg.pivot(index= ["permid"], columns = ["Date"], values = ["Close"])
                df_price_top_esg_ret = np.log(df_price_top_esg_pivot["Close"][i + ret]/df_price_top_esg_pivot["Close"][i])  
                # error in this line
                # add control variables from the greenwash returns
                #print (len(df_price_top_esg_ret))
                df_betas1 = df_betas[df_betas["permid"].isin(df_price_top_esg_ret.index)]
                
                df_fundamentals_7 = df_fundamentals_6[df_fundamentals_6["Date"]==i] # use only the control variables at the start of the period
                df_fundamentals_8 = df_fundamentals_7[df_fundamentals_7["permid"].isin(df_price_top_esg_ret.index)]
                # may consider to average out the values over the year
                #print(betas) seems to have some na values. 
                df_control = df_betas1.join(df_fundamentals_8.set_index("permid"), on="permid")
                #df_control["ret_ff"] = df_control["beta_bm"] * df_control["bm"] + df_control["beta_mom"] * df_control["MomentumL1Y"] + df_control["beta_mktcap"] * df_control["mkt_cap"] + df_control["beta_const"]
                df_control["ret_ff"] = df_control["beta_bm"] * df_control["bm"] + df_control["beta_mom"] * df_control["MomentumL1Y"] + df_control["beta_mktcap"] * df_control["mkt_cap"]  
                
                df_control = df_control[['permid', "ret_ff", 'Date']] 
                df_control = df_control.dropna()
                
                df_price_top_esg_ret1  = pd.DataFrame(df_price_top_esg_ret)
                #df_price_top_esg_ret1["permid"] = df_price_top_esg_ret1.index
                df_price_top_esg_ret1 = df_price_top_esg_ret1.rename(columns = {0:"ret"})
                df_price_top_esg_ret1 = df_price_top_esg_ret1[abs(df_price_top_esg_ret1["ret"]) < 1.0]
                df_price_top_esg_ret2 = df_price_top_esg_ret1.join(df_control.set_index("permid"))
                
                # greenwash premium by firm
                df_price_top_esg_ret2["industry"] = ind
                df_price_top_esg_ret2["pillar"] = key
                df_price_top_esg_ret2["permid"] = df_price_top_esg_ret2.index
                df_price_top_esg_ret2["e_ret"] = df_price_top_esg_ret2["ret"] - df_price_top_esg_ret2["ret_ff"]
                if iniit == 0:
                    df_greenwash_prem = df_price_top_esg_ret2[["Date", "permid", "industry", "pillar", "e_ret"]]
                    iniit = 1
                else:
                    df_greenwash_prem = pd.concat([df_greenwash_prem, df_price_top_esg_ret2[["Date", "permid", "industry", "pillar", "e_ret"]]])
                
                # this is the line if you want to average out considering only firms that greenwash OR not
                #df_greenwash_ret = np.sum(df_price_top_esg_ret)/n1
                df_greenwash_ret = np.mean(df_price_top_esg_ret2["e_ret"])
                greenwash_prem.append(df_greenwash_ret)
            
                # due to rounding error
                if len(df_common)/n1*qtiles > 1:
                    n_common_list.append(1.0)
                else:
                    n_common_list.append(len(df_common)/n1*qtiles)
            except IndexError:
                continue

 # #       Printing of time series plots
 #        fig = plt.figure()
 #        axs = fig.add_subplot()
 #        axs.plot(list_dates, greenwash_prem, label="Greenwash Premium", color = "red")
 #        axs.set_ylabel("Greenwash Premium")
 #        axs_t = axs.twinx() 
 #        axs_t.plot(list_dates, n_common_list, label="% of Firms Greenwashing", color = "blue")
 #        axs_t.set_ylabel("% of Firms Greenwashing")
 #        axs.set_title("Industry: " + ind + "; Metric: " + key)
 #        axs.set_xticks(xdates)
        
 #        lines_1, labels_1 = axs.get_legend_handles_labels()
 #        lines_2, labels_2 = axs_t.get_legend_handles_labels()
 #        lines = lines_1 + lines_2
 #        labels = labels_1 + labels_2
 #        axs.legend(lines, labels, loc=0)
 #        plt.savefig("Premium_" + ind + "_" + key + "3.png")# save each of the graphs; be careful as it is directly connected to latex
        greenwash = {"dates" : list_dates, "premium": greenwash_prem, "metric": [key] * len(list_dates) , "TRMA_scores": esg_scores_list, "no_of_firms": n_list, "No_firms_greenwash%": n_common_list, "industry": [ind] * len(list_dates)}
        #greenwash = {"dates" : list_dates, "News_premium": df_news_prem, "Compliance_prem" : df_asset4_prem, "Common_%": n_common_list }
        if stop == 0:
            df_greenwash = pd.DataFrame.from_dict(greenwash)
            stop =1
        else:
            df_greenwash = pd.concat([df_greenwash, pd.DataFrame.from_dict(greenwash)])

exc_dates = [date(2008,1,1),date(2009,1,1)]
#df_greenwash = df_greenwash[~df_greenwash["dates"].isin(exc_dates)]
df_greenwash.to_csv("df_greenwash_results.csv")
df_greenwash_res_1 = round(df_greenwash.pivot_table(values = "premium", index="metric", columns ="industry", sort = False),3)
df_greenwash_res_2 = round(df_greenwash.pivot_table(values = "premium", index="metric", columns ="industry",aggfunc="std", sort = False),3)
print(df_greenwash_res_1)
#df_greenwash_res_3 = scipy.stats.ttest_1samp(a, popmean, axis=0).

# compute t-test  #################
ind_list = []
key_list = []
ttest_list = []
iniit = 0
for ind in ["overall", "green", "brown", "consumer"]:
    df_greenwash_X = df_greenwash[df_greenwash["industry"]==ind]
    for metric in ["ESG", "E", "S", "G"]:
        df_greenwash_X2 = df_greenwash_X[df_greenwash_X["metric"]==metric]
        ind_list.append(ind)
        key_list.append(metric)
        ttest_list.append(ttest_1samp(df_greenwash_X2["premium"], 0, axis=0)[1])
df_greenwash_hypo = pd.DataFrame({"metric":key_list, "industry": ind_list, "t-test p-value" : ttest_list })
df_greenwash_res_3 = round(df_greenwash_hypo.pivot(values = "t-test p-value", index="metric", columns ="industry"), 3)
#df_greenwash_res_3 = round(df_greenwash_res_1/df_greenwash_res_2,3)

# Robustness test: OLS to validate source of greenwash prem
# merge sales figures and greenwash prem
df_salesresults = pd.DataFrame(columns=['id','brown_1','brown_2','brown_3','brown_4','consumer_1','consumer_2','consumer_3','consumer_4','green_1','green_2','green_3','green_4','overall_1','overall_2','overall_3','overall_4'])
df_salesresults['id'] = ["sale_equity", "sale_equity_p", "sale_invcap", "sale_invcap_p", "sale_nwc", "sale_nwc_p", "const", "const_p", "r2", "noofobs" ]
df_salesresults = df_salesresults.set_index("id")

df_greenwash_prem = df_greenwash_prem.reset_index(drop= True)
df_greenwash_prem1 = df_greenwash_prem.merge(df_sales, left_on=["permid", "Date"], right_on=["permid", "Yr Month"])
df_greenwash_prem2 = df_greenwash_prem1.drop_duplicates() 
df_greenwash_prem2 = df_greenwash_prem2[df_greenwash_prem2["sale_invcap"].apply(lambda x : not np.isinf(x))]

df_salesresults_all = {}
for pillar in ["ESG","E","S", "G"]:
    df_salesresults = pd.DataFrame(columns=['id','brown_1','brown_2','brown_3','brown_4','consumer_1','consumer_2','consumer_3','consumer_4','green_1','green_2','green_3','green_4','overall_1','overall_2','overall_3','overall_4'])
    df_salesresults['id'] = ["sale_equity", "sale_equity_p", "sale_invcap", "sale_invcap_p", "sale_nwc", "sale_nwc_p", "const", "const_p", "r2", "noofobs" ]
    df_salesresults = df_salesresults.set_index("id")
    df_reg1 = df_greenwash_prem2[df_greenwash_prem2["pillar"]==pillar]
    for ind in ["brown",  "consumer", "green", "overall"]:
        df_reg = df_reg1[df_reg1["industry"]==ind]
        i=1
        for idx, sales in enumerate(["sale_equity", "sale_invcap" , "sale_nwc", ["sale_equity" ,"sale_invcap" , "sale_nwc"]]):
            X = df_reg[sales] 
            X = sm.add_constant(X, prepend = False)
            Y =  df_reg[["e_ret"]]
            res = sm.OLS(Y, X).fit()
            if idx > 2:
                for j in sales:
                    df_salesresults.loc[j][ind+"_"+str(i)]= res.params[sales][j]
                    df_salesresults.loc[j+"_p"] [ind+"_"+str(i)]= res.pvalues[sales][j]
            else:
                 df_salesresults.loc[sales][ind+"_"+str(i)]= res.params[sales]
                 df_salesresults.loc[sales+"_p"] [ind+"_"+str(i)]= res.pvalues[sales]
                 
            df_salesresults.loc["const"][ind+"_"+str(i)] = float(res.params["const"])
            df_salesresults.loc["const_p"][ind+"_"+str(i)] = res.pvalues["const"]
            df_salesresults.loc["r2"][ind+"_"+str(i)] = res.rsquared
            df_salesresults.loc["noofobs"][ind+"_"+str(i)] = res.nobs
            i=i+1
           
    df_salesresults = df_salesresults.replace(np.nan,"-", regex=True)
    df_salesresults = round(df_salesresults,6)
    df_salesresults_all[pillar] = df_salesresults
    print("Regression result for industry  " + ind + " pillar " + pillar )
    print(df_salesresults)
    print(" -------------------- ")
