# -*- coding: utf-8 -*-
"""
Created on Fri Nov 11 23:20:38 2022

@author: jc822081
"""
# Greenwashing premium
# (A) 
# 1. Read in data for ESG sentiment and obtain monthly averages
# -*- coding: utf-8 -*-

import pandas as pd 
import zipfile
import os 

# 1. Read in data for ASSET4 data 
mypath = "C:\\Users\\jc822081\\OneDrive - James Cook University\\Academia\\Greenwashing\\Code\\data"
os.chdir(mypath + "\\asset4") 
# Combine (1) and (2) together. Obtain their prices to calculate returns later.
# Segment the firms into industries and also calculate the country as a wholey 
cols = ["Instrument", "Period End Date", "ESG Score", "Environment Pillar Score", "Social Pillar Score", "Governance Pillar Score"]
df_asset4 = pd.DataFrame()

filenames = next(os.walk(mypath + "\\asset4"), (None, None, []))[2] 
stop= 1
for f in filenames: 
    df = pd.read_csv(f,sep=",")
    df = df[cols]
    if stop == 1:
        df_asset4 = df
        stop = stop + 1
    else:
        df_asset4 = pd.concat([df_asset4,df], axis=0)
 
df_asset4 = df_asset4.rename(columns={"Instrument": "permid", "Period End Date":"Date"}) 
permids = df_asset4["permid"].unique()

# 2. Read in ESG data 

mypath = "C:\\Users\\jc822081\\OneDrive - James Cook University\\Academia\\Greenwashing\\Code\\data"
os.chdir(mypath) 
permids_map = pd.read_csv("map_permid.csv")
#permids_map = permids_map[permids_map["country"]=="United States"]
permids_map = permids_map[["permid", "orgname", "country", "industry"]]
df_asset = df_asset4.join(permids_map.set_index("permid"), on="permid")
df_asset = df_asset[df_asset["country"]=="United States"]
df_asset.to_csv(mypath + "\\df_asset4.csv")
#####
 
os.chdir(mypath + "\\monthly") 
prefix = "PRO.Archive.CMPNY_ESG.W365_UDAI."
years = range(2003,2022)
months = ["01", "06", "07", "12"]

cols = ["windowTimestamp","assetCode", "ESG", "EnvironmentalPillar", "GovernancePillar", "SocialPillar"]
col_scores = [ "ESG", "EnvironmentalPillar", "GovernancePillar", "SocialPillar"] 
df2  = pd.DataFrame() #names=["assetCode","date"], columns=["buzz","Emissions","EnvironmentalInnovation"])

print ("Finished asset4")
stop= 1
i=1
for yr in years:
     for mth in months:
         try:
            zf = zipfile.ZipFile(prefix + str(yr) + str(mth) + ".0400.zip") 
        #f = f.replace("zip", "txt")
            df = pd.read_csv(zf.open(prefix + str(yr) + str(mth) + ".0400.txt"),sep="\t")
         except FileNotFoundError:
            break
         except KeyError:  # there are some errors with file names from 202102 onwards
            df = pd.read_csv(zf.open(prefix + str(yr) + str(mth) + ".040" + str(i) + ".txt"),sep="\t")
            i=i+1                 
         df = df[cols]
         df["Yr Mth"] = str(yr) + "-" + str(mth)

         if stop == 1:
            df2 = df
            stop = stop + 1
         else:
            df2 = pd.concat([df2,df], axis=0)

df2 = df2[df2["assetCode"].isin(permids)]
df2 = df2.rename(columns={"assetCode":"permid"})
df3 = df2.groupby(["permid", "Yr Mth"], as_index=False).mean() 
df3 = df3.dropna(subset = col_scores, how='all')  # drop only if all the column values are NA
df3.to_csv(mypath + "\\df_esg.csv")
print ("Finished esg")

# 3. Read in prices for permids
df_price = pd.read_csv(mypath + "\\historical-prices-unadjusted.csv")
df_ref = pd.read_csv(mypath + "\\reference-data.csv")
df_ref_1 = df_ref[["permid", "ticker", "country" ]]
df_ref_1 = df_ref_1[df_ref_1["country"]=="USA"]

df_price = df_price.join(df_ref_1.set_index("ticker"), on="RIC")
df_price = df_price[df_price["country"]=="USA"]
df_price = df_price.drop(["RIC", "country"], axis=1)
df_price = df_price.rename(columns = {"Trade Date": "Date"})
df_price["Yr Month"] = df_price["Date"].map(lambda x : x[0:7])
df_price = df_price.drop(["Date"], axis = 1)
df_price1 = df_price.groupby(["permid", "Yr Month"], as_index=False).mean() 
df_price1.to_csv(mypath + "\\df_price.csv")

# 4. Obtain the firm fundamental data from WRDS
df_fundamentals = pd.read_csv(mypath + "\\raw_crsp_US_fun_ratios.csv")
df_ref_2 = df_ref[df_ref["country"]=="USA"]
df_ref_2 = df_ref_2[["permid", "RIC"]]
df_fundamentals = df_fundamentals.join(df_ref_2.set_index("RIC"), on="TICKER")
df_fundamentals = df_fundamentals[["permid", "public_date", 'bm', 'sale_invcap', 'sale_equity', 'sale_nwc']]
df_fundamentals.to_csv(mypath + "\\df_fundamentals.csv")
# 6. Greenwashing premium = Factor_asset4 - factor_ESG
# If the portfolios are the same, then the returns difference = 0;
# If the 2 portfolios are v different, or even opposite, the returns 
# Remember it is competition amongst firms that matter. 