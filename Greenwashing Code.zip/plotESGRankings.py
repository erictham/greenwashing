# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 17:30:19 2022

@author: jc822081
"""

import pandas as pd 
import numpy as np
import os 
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from matplotlib import pyplot as plt

# (B)
# 3. Set parameter - Year start
#                   - type of ESG metric
#                   - fulfillment period
# This graph plots out the average TRMA ESG sentiment scores and ASSET$ scores. 
start = datetime(2005,1,1)   
fulfill = relativedelta(years=+1)
# the 1st tuple (0) is for how MRNA (MarketPschy) labels its metrics
# and the 2nd (1) is for the asset4.
esg_metric = {'ESG': ("ESG" ,'ESG Score'), "E": ("EnvironmentalPillar", "Environment Pillar Score"), \
              "S": ("SocialPillar", "Social Pillar Score") , "G": ("GovernancePillar", "Governance Pillar Score") }
metric = "ESG"

mypath = "C:\\Users\\jc822081\\OneDrive - James Cook University\\Academia\\Greenwashing\\Code\\data"
os.chdir(mypath)

# Dissect into industries
permids_map = pd.read_csv("map_permid.csv")
permids_map = permids_map[permids_map["country"]=="United States"]
permids_map = permids_map[["permid", "industry"]]
industries_ = permids_map.groupby("industry").count()
industries = ["Consumer Cyclicals", "Consumer Non-Cyclicals", "Basic Materials", "Energy", "Utilities", "Technology", "Financials", "Healthcare"] 

industry_map = {"consumer" : ["Consumer Cyclicals", "Consumer Non-Cyclicals"], "brown": ["Basic Materials", "Energy", "Utilities"], "green" : ["Technology", "Financials", "Healthcare"] }
industry_map_1 = { v: k for k, l in industry_map.items() for v in l}

df_asset4_1 = pd.read_csv("df_asset4.csv")
df_asset4_1["Date"] = df_asset4_1["Date"].map(lambda x : datetime.strptime(x, "%Y-%m-%d") + timedelta(days=1))
df_asset4 = df_asset4_1[df_asset4_1["country"]=="United States"]
df_asset4 = df_asset4[["permid", 'ESG Score', "Environment Pillar Score", "Social Pillar Score", "Governance Pillar Score", "Date"]] 
### Comment out this section if you want ony inudstry level results
df_asset4 = df_asset4.join(permids_map.set_index("permid"), on = "permid")
df_asset4 = df_asset4[df_asset4["industry"].isin(industries)]
df_asset4["industry_type"] = df_asset4["industry"].map(lambda x : industry_map_1[x])

##  Actual data input

df_esg = pd.read_csv("df_esg.csv") 
df_esg["Date"] = df_esg["Yr Mth"].map(lambda x : datetime.strptime(x + "-01", "%Y-%m-%d") + relativedelta(months=+1))
df_esg = df_esg[["permid", "ESG", "EnvironmentalPillar", "SocialPillar", "GovernancePillar",  "Date"]]

df_price = pd.read_csv("df_price.csv") # these are monthly prices
df_price["Date"] = df_price["Yr Month"].map(lambda x : datetime( int(x[0:4]), int(x[5:7]), 1))
df_price = df_price[["permid", "Close", "Date"]]

mypath = "C:\\Users\\jc822081\\OneDrive - James Cook University\\Academia\\Greenwashing"
os.chdir(mypath)

asset4_list =  []
dat = np.arange(0,17)
df_asset4_scores = {}
df_esg_scores = {}

df_asset4_scores_2 = {}
df_esg_scores_2 = {}
correl = {}

list_dates = [start + relativedelta(years=+d) for d in dat] #, datetime(2021,1,1)]
xdates = [date(2005,1,1),date(2010,1,1),date(2015,1,1), date(2021,1,1)]
df_asset4_scores["Dates"] = list_dates
df_esg_scores["Dates"] = list_dates
df_asset4_scores_2["Dates"] = list_dates
df_esg_scores_2["Dates"] = list_dates

for key, value in esg_metric.items():
    df_esg_scores_1=[]
    df_asset4_score_1=[]
    
    df_esg_scores_sd=[]
    df_asset4_score_sd=[]
    
    for i in list_dates:
        try:
            #print(key)      
            df_esg_1 = df_esg[df_esg["Date"]==i]
            df_esg_1 = df_esg_1.dropna(subset = value[0], how='all')
            
            df_asset4_1 = df_asset4[df_asset4["Date"] == i ]
            #df_asset4_1 = df_asset4_1[df_asset4_1["industry_type"]=="consumer"]
            df_asset4_2 = df_asset4_1.dropna(subset = value[1], how='all')
            
            #asset4_list.append(len(df_asset4_2[df_asset4_2[value[1]]==0]))  # how many of the values are =0
            
            df_esg_2 = df_esg_1[df_esg_1["permid"].isin(df_asset4_1["permid"].unique())]
            df_asset4_1 = df_asset4_1[df_asset4_1["permid"].isin(df_esg_2["permid"].unique())]
            
            n1 = len(df_esg_2)
            n2 = len(df_asset4_1)
            assert n1 == n2
            #print(n1)
            
            df_esg_scores_1.append(np.mean(df_esg_2[value[0]]))
            df_asset4_score_1.append(np.mean(df_asset4_1[value[1]]))
                        
            df_esg_scores_sd.append(np.std(df_esg_2[value[0]]))
            df_asset4_score_sd.append(np.std(df_asset4_1[value[1]]))            
            
        except IndexError:
            continue
    df_esg_scores[key]=df_esg_scores_1
    df_asset4_scores[key]=df_asset4_score_1
    
    df_esg_scores_2[key]=df_esg_scores_sd
    df_asset4_scores_2[key]=df_asset4_score_sd
    
    correl[key] = np.corrcoef(df_esg_scores_1, df_asset4_score_1)[0][1]
    # plot graph
    fig, axs = plt.subplots(constrained_layout=True)
    #axs.errorbar(list_dates, df_esg_scores[key], [i*0.5 for i in df_esg_scores_sd], label= "ESG News Score: " + key + " Pillar", color = "red")
    axs.plot(list_dates, df_esg_scores[key], label= "ESG News Score: " + key + " Pillar", color = "red")
    axs.set_ylabel("ESG Scores")
    #axs_t = axs.twinx() 
    #axs.errorbar(list_dates, df_asset4_scores[key], [i*0.5 for i in df_asset4_score_sd], label="ESG Performance score: " + key + " Pillar", color = "blue")
    axs.plot(list_dates, df_asset4_scores[key], label="ESG Performance score: " + key + " Pillar", color = "blue")
    axs.set_title("Pillar: " + key )
    axs.set_xticks(xdates)
    axs.legend(loc = "upper right")
    plt.savefig(key + "_scores.png")
    
        
df_esg_scores = pd.DataFrame.from_dict(df_esg_scores)
df_asset4_scores = pd.DataFrame.from_dict(df_asset4_scores)

df_esg_scores_2 = pd.DataFrame.from_dict(df_esg_scores_2)       # standard deviation
df_asset4_scores_2 = pd.DataFrame.from_dict(df_asset4_scores_2)